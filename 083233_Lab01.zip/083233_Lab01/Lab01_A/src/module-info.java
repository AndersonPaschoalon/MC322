module Lab01_A {
}