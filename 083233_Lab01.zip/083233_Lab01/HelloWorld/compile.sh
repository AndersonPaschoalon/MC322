#!/bin/bash
javac HelloWorld.java



